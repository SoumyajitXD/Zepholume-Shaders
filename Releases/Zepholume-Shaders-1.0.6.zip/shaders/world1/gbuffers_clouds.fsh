#version 330 compatibility
#define ZEPH_DIM_END
#include "/lib/cloud_fragment.glsl"

#ifndef ZEPHO_LIGHTING_GLSL
#define ZEPHO_LIGHTING_GLSL

#ifndef ZEPH_HAS_SUN_POSITION
uniform vec3 sunPosition;
#endif
#ifndef ZEPH_HAS_MOON_POSITION
uniform vec3 moonPosition;
#endif

float zephDaylightFromSun() {
    return zephDaylightFromDirection(sunPosition);
}

float zephFaceLight(vec3 normal, vec2 lightCoord, float storm) {
#if ZEPH_EFFECTIVE_FACE_LIGHTING_QUALITY == 0
    return 1.0;
#elif defined(ZEPH_DIM_NETHER)
    // Nether has no celestial bodies. Ambient vertical fill creates cavern depth
    // without phantom directional shadows from an invisible sun.
    float upward = zephWorldElevation(normal) * 0.5 + 0.5;
    return mix(0.85, 1.05, upward);
#elif defined(ZEPH_DIM_END)
    // The End has no celestial sun/moon. Omnidirectional void-grounded ambient.
    float upward = max(zephWorldElevation(normal), 0.0);
    return mix(0.88, 1.02, upward * 0.6 + 0.4);
#else
    vec3 sunDir = zephSafeNormalize(sunPosition);
    vec3 moonDir = zephSafeNormalize(moonPosition);
    float daylight = zephDaylightFromDirection(sunDir);

    // The lightmap and vertex colour already carry the main scene lighting.
    // Use celestial direction only for bounded face shape, not a second deep
    // attenuation of valid skylight or block light.
    float sunDirect = max(dot(normal, sunDir), 0.0);
    float dayFace = mix(0.72, 1.0, sunDirect);

    // Night directional moonlight with grounded non-facing ambient
    float moonDirect = max(dot(normal, moonDir), 0.0);
    float nightFace = mix(0.72, 0.88, moonDirect * 0.55 + 0.45);

#if ZEPH_EFFECTIVE_FACE_LIGHTING_QUALITY >= 3
    // High and Ultra apply softened wrap curve for smoother facet transitions
    dayFace = mix(dayFace, sqrt(max(dayFace, 0.0)), 0.22);
    nightFace = mix(nightFace, sqrt(max(nightFace, 0.0)), 0.15);
#endif

    // Soften directional contrast during overcast storms
    dayFace = mix(dayFace, 0.78, storm * 0.45);
    nightFace = mix(nightFace, 0.80, storm * 0.30);

    float rawCelestial = mix(nightFace, dayFace, daylight);

    // Ground directional contrast using skylight (lightCoord.y).
    // Deep caves and interiors (skyLight -> 0) transition to isotropic ambient (1.0),
    // preventing outdoor sun/moon directional contrast from penetrating underground.
    float skyLight = lightCoord.y;
    // Exact smoothstep shape with a compile-time reciprocal range.  The
    // reciprocal form is algebraically equivalent to the normalized input;
    // no GPU performance claim is implied without target-driver evidence.
    const float ZEPH_SKYLIGHT_INV_RANGE = 1.639344262295082;
    float tSky = clamp((skyLight - 0.04) * ZEPH_SKYLIGHT_INV_RANGE, 0.0, 1.0);
    float celestialWeight = tSky * tSky * (3.0 - 2.0 * tSky);
    return mix(1.0, rawCelestial, celestialWeight);
#endif
}

vec3 zephBlockLightWarmth(vec3 linearColour, vec2 lightCoord) {
#if ZEPH_EFFECTIVE_FACE_LIGHTING_QUALITY == 0
    return linearColour;
#else
    // Relative block-light dominance:
    // Torches, lanterns, and fire emit warm incandescent light (~2700K-3200K).
    // Modulate warmth by the ratio of block light (lightCoord.x) to skylight (lightCoord.y),
    // preventing broad daylight from acquiring an orange tint while making dark interiors
    // and caves richly incandescent without clipping or destroying cool material chroma.
    float blockLight = lightCoord.x;
    float skyLight = lightCoord.y;
    float dominance = blockLight / max(blockLight + skyLight * 0.75 + 0.001, 0.001);
    // Exact smoothstep shape with a compile-time reciprocal range.
    const float ZEPH_BLOCK_LIGHT_INV_RANGE = 1.25;
    float tWarmth = clamp((blockLight - 0.10) * ZEPH_BLOCK_LIGHT_INV_RANGE, 0.0, 1.0);
    float warmthFactor = (tWarmth * tWarmth * (3.0 - 2.0 * tWarmth)) * dominance;

#if ZEPH_EFFECTIVE_FACE_LIGHTING_QUALITY == 1
    float strength = 0.28;
#elif ZEPH_EFFECTIVE_FACE_LIGHTING_QUALITY == 2
    float strength = 0.42;
#else
    float strength = 0.55;
#endif

    vec3 warmTint = vec3(1.09, 0.985, 0.87);
    return linearColour * mix(vec3(1.0), warmTint, warmthFactor * strength);
#endif
}

vec3 zephApplySceneLighting(vec3 linearColour, vec3 normal, vec2 lightCoord, float storm) {
#if ZEPH_EFFECTIVE_FACE_LIGHTING_QUALITY == 0
    return linearColour;
#else
    vec3 lit = linearColour * zephFaceLight(normal, lightCoord, storm);
#if ZEPH_EFFECTIVE_FACE_LIGHTING_QUALITY >= 3 && !defined(ZEPH_DIM_NETHER) && !defined(ZEPH_DIM_END)
    // High & Ultra dual-hemisphere ambient irradiance: upward surfaces receive subtle cool sky fill,
    // downward surfaces receive subtle warm ground bounce.
    float up = zephWorldElevation(normal) * 0.5 + 0.5;
    vec3 skyHemisphere = vec3(0.96, 0.98, 1.04);
    vec3 groundBounce = vec3(1.02, 0.99, 0.96);
    vec3 domeFill = mix(groundBounce, skyHemisphere, up);
    lit *= mix(vec3(1.0), domeFill, lightCoord.y * 0.12);
#endif
    return zephBlockLightWarmth(lit, lightCoord);
#endif
}

#endif

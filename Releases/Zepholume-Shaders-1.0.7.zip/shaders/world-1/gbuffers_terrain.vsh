#version 330 compatibility
#define ZEPH_DIM_NETHER
#define ZEPH_TERRAIN_PROGRAM
#include "/lib/vertex.glsl"
